import java.sql.SQLException;
import java.util.*;
public class Main {

	public static void main(String[] args) throws SQLException
	{
		Authentication a=new Authentication();
		Scanner sc=new Scanner(System.in); 
		System.out.println();
		System.out.println("------------WELCOME TO OXYGEN MANAGEMENT SYSTEM------------");
		System.out.println();
		System.out.println("Enter 1 to Login");
		System.out.println("Enter 2 to Register");
		System.out.println("Enter 3 to Exit");
		int input=sc.nextInt();
		switch(input)
		{
		case 1:
		{
			System.out.println("1. Login as User");
			System.out.println("2. Login as Admin");
			int option=sc.nextInt();
			switch(option)
			{
			case 1:{
				a.loginUser();
				break;
			}
			case 2:{
				a.admin();
				break;
			}
			default:{
				System.out.println("--------Invalid Option Please Enter the Valid Option given above--------");
			}
			break;
		}
		}
		case 2:
		{
			a.register();
			break;
		}
		case 3:
		{
			System.out.println("Exiting oxygen management System.....");
			break;
		}
		default:
		{
			System.out.println("--------Invalid Option Please Enter the Valid Option given above--------");
			break;
		}
	}
}
}