import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class PaymentDB 
{

	private static Connection con = null;
	
	static
	{
		String url = "jdbc:mysql://localhost:3306/oxygen";
		String user = "root";
		String pass = "Tanushri@9942149079";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);
		}
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection()
	{
		return con;
	}
	Scanner sc=new Scanner(System.in);
	public void Pay(String User, String Product, int Quantity, int Price, String Status) throws SQLException
	{
		String query = "insert into Payment(User, Product, Quantity, Price, Status) values(?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1, User);
		ps.setString(2, Product);
		ps.setInt(3, Quantity);
		ps.setInt(4, Price);
		ps.setString(5, Status);
		int r=ps.executeUpdate();		
	}
	static int money=0;
 public int pay1(int n) throws SQLException
	{
		String query =" select OPrice from details where Id =?";
		PreparedStatement ps = con.prepareStatement(query);
		ps.setInt(1,n);
		ResultSet rs=ps.executeQuery();
		money=0;
		int x=1;
		while(rs.next()) {
			money=rs.getInt(1);
		}
		return money;
	}

}