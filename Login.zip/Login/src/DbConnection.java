import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class DbConnection 
{

	private static Connection con = null;
	
	static
	{
		String url = "jdbc:mysql://localhost:3306/oxygen";
		String user = "root";
		String pass = "Tanushri@9942149079";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);
		}
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection()
	{
		return con;
	}
	Scanner sc=new Scanner(System.in);
	public void register(String user, String gmail, String password, String PhoneNo) throws SQLException 
	{
	String query="insert into register(Name,Gmail,Password,PhonNo)values(?,?,?,?)";
	PreparedStatement p= con.prepareStatement(query);
		p.setString(1, user);
		p.setString(2, gmail);
		p.setString(3, password);
		p.setString(4, PhoneNo);
		int r=p.executeUpdate();
		if(r>0)
		{
			System.out.println("\n-------Registered Successfully!!------- ");
			CustomerPage obj=new CustomerPage();
			obj.CustomerOption();
		}
		else {
			System.out.println("Invalid Registration Please Enter valid MailId and Password...");
		}
	}
	public void loginUser(String gmail) throws SQLException
	{
		Authentication a =new Authentication();
		String query = "select Gmail from register where Gmail = ?;";
		PreparedStatement p=con.prepareStatement(query);
		p.setString(1,gmail);
		ResultSet rs=p.executeQuery();
		String mail="";
		while(rs.next()) {
			mail=rs.getString(1);
		}
		if(!(mail.equals(gmail))) {
			System.out.println("\n** Invalid EmailId  **");
			System.out.println("\n** If not yet Registered Enter 'YES' else 'NO' **");
			String yn=sc.next();
			if(yn.equalsIgnoreCase("Yes")) {
				a.register();
			}
			else {
				a.loginUser();
			}
		}
		else {
			System.out.println("Enter the Password: ");
			String password=sc.next();
			String query1="select Gmail, Password from register where Gmail=?;";
			PreparedStatement ps=con.prepareStatement(query1);
			ps.setString(1, gmail);
			ResultSet rs1=ps.executeQuery();
			while(rs1.next()) {
				if(gmail.equals(rs1.getString(1)) && password.equals(rs1.getString(2))) {
					System.out.println("----------Logged In---------");
					CustomerPage obj=new CustomerPage();
					obj.CustomerOption();
				}
				else {
					System.out.println("** Not LoggedIn **");
					System.out.println("Login Again");
					CustomerPage obj=new CustomerPage();
					obj.CustomerOption();
				}
			}
		}
	}
	public void admin(String gmail, String password) throws SQLException {
		Authentication a=new Authentication();
		String query = "select Gmail, Password from adminLogin where Gmail=? and Password=?;";
		PreparedStatement ps=con.prepareStatement(query);
		ps.setString(1, gmail);
		ps.setString(2, password);
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			if(gmail.equals(rs.getString(1)) && password.equals(rs.getString(2))) {
				System.out.println("-------Admin login Successfull------");
				AdminPage obj=new AdminPage();
				obj.details();
			}
			else {
				System.out.println("** Not LoggedIn **");
				a.admin();
			}
		}
		AdminPage obj=new AdminPage();
		obj.details();
	}
	public void viewPayment() throws SQLException
	{
		String query = "select User,Product, Quantity, price, status from payment";
		PreparedStatement ps = con.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		System.out.println("+-----------+------------------+----------------+----------+---------------+");
        System.out.println("|    Name   | Product          |   Quantity     | Price    | Status       |");
        System.out.println("+-----------+------------------+----------------+----------+---------------+");
		while(rs.next()) {
			String name = rs.getString("User");
			String poduct = rs.getString("Product");
			int qnty = rs.getInt("Quantity");
			int price = rs.getInt("Price");
			String st= rs.getString("Status");
			System.out.printf("| %-10s | %-15s | %-15d | %-8d | %-10s |\n", name, poduct, qnty, price, st);
	        System.out.println("+-----------------------------------------------------------------------+");		
	        }
	}
}