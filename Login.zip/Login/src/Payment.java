import java.sql.PreparedStatement;
//import static .con;
import java.sql.SQLException;
import java.util.*;
public class Payment 
{
    Scanner sc=new Scanner(System.in);
    PaymentDB obj = new PaymentDB();
	public void OxygenPay() throws SQLException
	{
		int p=0;
		PaymentDB pd=new PaymentDB();
		System.out.println("Enter the UserName:");
		String userName = sc.nextLine();
		System.out.println("Enter the Id of the Oxygen:");
		int id = sc.nextInt();
		int price=pd.pay1(id);
		System.out.println("Enter the Quantity:");
		int qnty = sc.nextInt();
		
		System.out.println("The Cost of 1 Oxygen :"+price);
		System.out.println("The cost of your order is "+(price*qnty));
		System.out.println("Pay the Cash:");
		int input=sc.nextInt();
		String product="Oxygen";
		if(input==(price*qnty)) {
			System.out.println("Paid");
			String s="Paid";
			obj.Pay(userName, product, qnty, price, s );
			CustomerPage cp=new CustomerPage();
			cp.CustomerOption();
		}
		else {
			System.out.println("Not Paid");
			String s="Not Paid";
			obj.Pay(userName, product, qnty, price, s );
	}
	}
	public void ConcentratorPay() throws SQLException {
		System.out.println("Enter the UserName: ");
		String userName=sc.nextLine();
		System.out.println("Enter the Quantity of Concentrator: ");
		int qnty=sc.nextInt();
		int price=1500;
		System.out.println("The cost of your order is "+(qnty*price));
		System.out.println("Pay the Cash:");
		int input = sc.nextInt();
		String product = "Concentrator";
		if(input == (qnty*price)) 
		{
			String s="Paid";
			System.out.println("Paid");
			obj.Pay(userName, product, qnty, price, s );
			CustomerPage cp=new CustomerPage();
			cp.CustomerOption();
		}
		else  {
			System.out.println("Not Paid");
			String s="Not Paid";
			obj.Pay(userName, product, qnty, price, s );
		}
	}
	public void MaskPay() throws SQLException {
		System.out.println("Enter the UserName: ");
		String userName=sc.nextLine();
		System.out.println("Enter the Quantity of Mask: ");
		int qnty=sc.nextInt();
		int price=594;
		System.out.println("The cost of your order is "+(qnty*price));
		System.out.println("Pay the Cash:");
		int input = sc.nextInt();
		String product = "Concentrator";
		if(input == (qnty*price)) {
			String s="Paid";
			System.out.println("Paid");
			obj.Pay(userName, product, qnty, price, s );
			CustomerPage cp = new CustomerPage();
			cp.CustomerOption();
		}
		else {
			System.out.println("Not Paid");
			String s="Not Paid";
			obj.Pay(userName, product, qnty, price, s );
		}
	}
}
