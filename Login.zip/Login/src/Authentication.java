import java.util.*;
import java.sql.*;
public class Authentication 
{
    Scanner sc=new Scanner(System.in);
    DbConnection obj=new DbConnection();
	public void register() throws SQLException 
	{
		System.out.println("Enter the UserName");
		String user=sc.nextLine();
		System.out.println("Enter the GmailId");
		String Gmail=sc.nextLine();
		System.out.println("Enter the Password");
		String password=sc.nextLine();
		System.out.println("Enter the PhoneNo");
		String PhoneNo=sc.nextLine();
		obj.register (user,Gmail,password,PhoneNo);
	}
	public void loginUser() throws SQLException 
	{
		System.out.println("Enter the GmailId");
		String Gmail=sc.nextLine();
		obj.loginUser(Gmail);
	}
	public void admin() throws SQLException
	{
		System.out.println("Enter Admin Email and Password To LogIn");
		System.out.println("Enter Your EmailId");
		String Gmail=sc.nextLine();
		System.out.println("Enter your Password");
		String password=sc.nextLine();
		obj.admin(Gmail,password);
	}       
}