import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class CustomerDB {

	private static Connection con = null;
	
	static
	{
		String url = "jdbc:mysql://localhost:3306/oxygen";
		String user = "root";
		String pass = "Tanushri@9942149079";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);
		}
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection()
	{
		return con;
	}
	Scanner sc=new Scanner(System.in);
	public void OxygenDetails() throws SQLException
	{
		String query = "Select Id, OType, OVolume, OQuantity, OPrice from details";
		PreparedStatement ps = con.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		System.out.println("+----+------------+-----------------+-----------------+--------------+");
        System.out.println("| ID | Type       | Volume          | Quantity        | Price        |");
        System.out.println("+----+------------+-----------------+-----------------+--------------+");
		while(rs.next()) {
			int id = rs.getInt("Id");
			String type = rs.getString("OType");
			String volume = rs.getString("OVolume");
			String quantity = rs.getString("OQuantity");
			int pr = rs.getInt("OPrice");
			System.out.printf("| %-2d | %-10s | %-15s | %-15s | %-12s |\n", id, type, volume, quantity, pr);
	        System.out.println("+----+------------+-----------------+-----------------+--------------+");
		}
		System.out.println("\nEnter 'Yes' to buy the Oxygen or Enter 'No'");
		String option = sc.nextLine();
		if(option.equalsIgnoreCase("Yes"))
		{
			Payment obj= new Payment();
			obj.OxygenPay();
		}
		else
		{
			System.out.println("Invalid Option Please Try Again......");
			System.out.println();
			CustomerPage cp = new CustomerPage();
			cp.CustomerOption();
		}
	}
	public void concentrator() throws SQLException 
	{
		System.out.println("Would you like to buy the Oxygen Concentrator ? ");
		System.out.println("Enter 'Yes' to Buy or 'No' to Exit");
		String option = sc.nextLine();
		if(option.equalsIgnoreCase("yes"))
		{
			Payment obj= new Payment();
			obj.ConcentratorPay();
		}
		else
		{
			CustomerPage cp = new CustomerPage();
			cp.CustomerOption();
		}
	}
	public void mask() throws SQLException 
	{
		System.out.println("Would you like to buy the Oxygen Mask ? ");
		System.out.println("Enter 'Yes' to Buy or 'No' to Exit");
		String option = sc.nextLine();
		if(option.equalsIgnoreCase("yes"))
		{
//			System.out.println("Enter the Quantity of Mask you would like to buy: ");
			Payment obj= new Payment();
			obj.MaskPay();
		}
		else
		{
			CustomerPage cp = new CustomerPage();
			cp.CustomerOption();
		}
	}
}
