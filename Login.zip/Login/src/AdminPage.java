import java.sql.SQLException;
import java.util.*;
public class AdminPage
{
	AdminDB admin=new AdminDB();
	Scanner sc=new Scanner(System.in);
	public void details() throws SQLException
	{
		System.out.println("1. To View Product");
		System.out.println("2. To View Customer Details");
		System.out.println("3. To Remove Products");
		System.out.println("4. To Add Products");
		System.out.println("5. To View Payment Details");
		System.out.println("6. Exit");
		int input=sc.nextInt();
		switch(input)
		{
		  case 1:
		  {
			vProduct();
			break;
		  }
		  case 2:
		  { 
			vCustomer();
			break;
		  }
		  case 3:
		  {
			  rProducts();
			  break;
		  }
		  case 4:
		  {
			  aProducts();
			  break;
		  }
		  case 5:
		  {
			  pay();
			  break;
		  }
		  default:
		  {
			  System.out.println("\n Logging Out");
			  System.out.println("--------Exiting Oxygen Management System---------");
			  System.exit(200);
		  }
	   }
    }
	

	public void vProduct() throws SQLException {
		admin.viewProduct();
	}
    public void vCustomer() throws SQLException {
    	admin.viewCustomer();
	}
    public void rProducts() throws SQLException{
    	System.out.println("Enter the Id that you want to remove:");
    	int Id = sc.nextInt();
    	admin.removeProducts(Id);
	}
    public void aProducts() throws SQLException {
    	System.out.println("Enter the Type of Oxygen you want to add to the Existing System: ");
    	sc.nextLine();
    	String type=sc.nextLine();
    	
    	System.out.println("Enter the Volume of the Oxygen you want to add to the Existing System: ");
    	String volume=sc.nextLine();
    	
    	System.out.println("Enter the Quantity of the Oxygen you want to add to the Existing System: ");
    	String quantity=sc.nextLine();
    	
    	System.out.println("Enter the Price of the Oxygen you want to add to the Existing System: ");
    	int price=sc.nextInt();
    	admin.addProducts(type, volume, quantity, price);
    }
    public  void pay() throws SQLException{
		admin.viewPayment();
	}
}