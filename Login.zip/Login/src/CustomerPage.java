import java.sql.SQLException;
import java.util.*;
public class CustomerPage 
{
	CustomerDB customer=new CustomerDB();
	Scanner sc=new Scanner(System.in);
	public void CustomerOption() throws SQLException
	{
    System.out.println("1. To Buy Oxygen");
    System.out.println("2. To Buy Oxygen Concentrator");
    System.out.println("3. To Buy Oxygen Mask");
    System.out.println("4. Exit");
    int option = sc.nextInt();
    switch(option)
    {
    case 1:
    {
    	oxygen();
    	break;
    }
    case 2:
    {
    	oxygenConcentrator();
    	break;
    }
    case 3:
    {
    	oxygenMask();
    	break;
    }
    case 4:
    {
    	System.out.println("\nLogging Out");
    	System.out.println("Exiting oxygen management System.....");
    	System.exit(200);
    }
	}
    }
	public void oxygen() throws SQLException
	{
		System.out.println("1. To view Oxygen and types");
		System.out.println("2. Exit"); 
		int option = sc.nextInt();
		if(option==1) {
			customer.OxygenDetails();
		}
		else 
		{
			System.out.println("\n Logging Out");
			System.out.println("Exiting oxygen management System.....");
			System.exit(0);
		}
	}
	public void oxygenConcentrator() throws SQLException 
	{
		System.out.println("1. Enter the quantity of oxygen concentrator: ");
		System.out.println("2. Exit"); 
		int option = sc.nextInt();
		switch(option)
		{
		case 1:{
			customer.concentrator();
			break;
			}
		}
	}
	public void oxygenMask() throws SQLException 
	{
		System.out.println("1. Enter the quantity of oxygen mask: ");
		System.out.println("2. Exit");
		int option = sc.nextInt();
		switch(option)
		{
		case 1:{
			customer.mask();
			break;
		}
		default:
		{
			System.out.println("\n Logging Out");
			System.out.print("\nExiting oxygen management System.....");
			break;
		}
		}
	}
}