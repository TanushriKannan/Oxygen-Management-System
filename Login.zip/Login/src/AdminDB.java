import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class AdminDB {

	private static Connection con = null;
	static
	{
		String url = "jdbc:mysql://localhost:3306/oxygen";
		String user = "root";
		String pass = "Tanushri@9942149079";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);
		}
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection()
	{
		return con;
	}
	Scanner sc=new Scanner(System.in);
	public void viewProduct() throws SQLException
	{
		String query = "Select Id, OType, OVolume, OQuantity, OPrice from details";
		PreparedStatement ps = con.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		System.out.println("-------------+------------+--------------+--------------+---------------");
        System.out.println("|     ID     |     Type   |    Volume    |    Quantity  | Price        |");
        System.out.println("-------------+------------+--------------+--------------+---------------");
		while(rs.next()) {
			int id = rs.getInt("Id");
			String type = rs.getString("OType");
			String volume = rs.getString("OVolume");
			String quantity = rs.getString("OQuantity");
			int pr = rs.getInt("OPrice");
			System.out.printf("%-10s | %-10s | %-15s | %-15s | %-12s |\n", id, type, volume, quantity, pr);
	        System.out.println("----------+------------+-----------------+-----------------+--------------+");
		}
		AdminPage ap = new AdminPage();
        ap.details();
	}
	public void viewCustomer() throws SQLException
	{
		String query = "select Name, Gmail, Password, PhonNo from register";
		PreparedStatement ps = con.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		System.out.println("+----------------------+--------------------------------+--------------------+-----------------+");
        System.out.printf("| %-20s | %-30s | %-20s | %-15s |\n", "Name", "Gmail", "Password", "Phone Number");
        System.out.println("+----------------------+--------------------------------+--------------------+-----------------+");
		while(rs.next()) {
			String name = rs.getString("Name");
			String gmail = rs.getString("Gmail");
			String password = rs.getString("Password");
			String phno = rs.getString("PhonNo");
	        System.out.printf("| %-20s | %-30s | %-20s | %-15s |\n", name, gmail, password, phno);
	        System.out.println("+----------------------+--------------------------------+--------------------+-----------------+");
		}
		AdminPage ap = new AdminPage();
        ap.details();
	}
	public void removeProducts(int Id) throws SQLException
	{
		System.out.println("\nKindly Enter 'Yes' to confirm else 'No' :");
		String option = sc.next();
		String query = "delete from details where Id = ? ";
		PreparedStatement ps = con.prepareStatement(query);
		ps.setInt(1, Id);
		if (option.equalsIgnoreCase("Yes")) {
		int r=ps.executeUpdate();
		System.out.println("\nData has been successfully removed as per your request");
		AdminPage ap = new AdminPage();
        ap.details();
		}
		else {
			AdminPage ap = new AdminPage();
        ap.details();
		}
	}
	public void addProducts(String type, String volume, String quantity, int price) throws SQLException
	{
		System.out.println("\nkindly enter 'Yes' to confirm else 'No' :");
		String option =  sc.nextLine();
		String query = "insert into details (OType, OVolume, OQuantity, OPrice) values(?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1, type);
		ps.setString(2, volume);
		ps.setString(3, quantity);
		ps.setInt(4, price);
		if(option.equalsIgnoreCase("yes")) {
		int r =ps. executeUpdate();
		System.out.println("\nData has been added successfully as per your request");
		sc.nextLine();
		AdminPage ap = new AdminPage();
        ap.details();
		}
		else {
			AdminPage ap = new AdminPage();
            ap.details();
		}
	}
	public void viewPayment() throws SQLException
	{
		String query = "select User,Product, Quantity, price, status from payment";
		PreparedStatement ps = con.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		System.out.println("+-----------+------------------+----------------+----------+---------------+");
        System.out.println("|    Name   | Product          |   Quantity     | Price    | Status       |");
        System.out.println("+-----------+------------------+----------------+----------+---------------+");
		while(rs.next()) {
			String name = rs.getString("User");
			String poduct = rs.getString("Product");
			int qnty = rs.getInt("Quantity");
			int price = rs.getInt("Price");
			String st= rs.getString("Status");
			System.out.printf("| %-10s | %-15s | %-15d | %-8d | %-10s |\n", name, poduct, qnty, price, st);
	        System.out.println("+-----------------------------------------------------------------------+");		
	        }
	}
}
